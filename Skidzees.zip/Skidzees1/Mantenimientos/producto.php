<?php
include_once 'Conexion/conexion.php';
$objeto = new conexion();
$conexion = $objeto->conectar();

$consulta = "SELECT * FROM Producto";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width-divece-width, initial-scale=1 shrink-to-fit=no">
	<link rel="shortcut icon" href="#">
<title>Documento sin título</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css">
	<link rel="stylesheet" type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
</head>
<body>
	<header>

	</header>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<button id="btnNuevo" type="button" class="btn btn-outline-success" data-toggle="modal" data-target="#modalCrud">Nuevo</button>
		</div>
		</div>
	</div>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<div class="table-responsive">
			<table id="tabla" class="table table-striped table-bordered table-condensed" style="width: 100%">
				<thead class="text-center">
				<tr>
					<th>Categoria</th>
					<th>nombre</th>
					<th>Precio</th>
					<th>Detalle</th>
					<th>Cantidad</th>
					<th>Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($data as $dat){
					?>
					<tr>
					<td>
							<?php
									$sentencia = "CALL SeleccionarNombreCategoria (".$dat['id_categoria'].")";
									$resultado = $conexion->prepare($sentencia);
									$resultado->execute();
									$cat = $resultado->fetchAll(PDO::FETCH_ASSOC);
									echo $cat[0]['nombre_categoria'];
							 ?>
					</td>
					<td><?php echo $dat ['nombre_producto']?></td>
					<td><?php echo $dat ['precio']?></td>
					<td><?php echo $dat ['detalle']?></td>
					<td><?php echo $dat ['cantidad']?></td>
					<form class="" action="" method="post">
						<td>
							<input type="submit" name="Editar" value="Editar" class="btn btn-primary">
							<input type="submit" name="Eliminar" value="Eliminar" class="btn btn-danger">
					  </td>

						<input type="hidden" name="id" value="<?php echo $dat['id_producto'] ?>">
						<input type="hidden" name="nombre" value="<?php echo $dat['nombre_producto'] ?>">
						<input type="hidden" name="precio" value="<?php echo $dat['precio'] ?>">
						<input type="hidden" name="detalle" value="<?php echo $dat['detalle'];?>">
						<input type="hidden" name="cantidad" value="<?php echo $dat['cantidad'] ?>">
						<input type="hidden" name="id_categoria" value="<?php echo $dat['id_categoria'] ?>">
					</form>
					</tr>
					<?php
					}
						?>
				</tbody>

				</table>
			</div>
		</div>
		</div>
	</div>
	<!--Modal Crud-->
	<div class="modal fade" id="modalCrud" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Producto Nuevo</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container">
					<form class="" action="Mantenimientos/crud_producto.php" method="post">
						<div class="form-group">
							<table>
								<tr>
									<td>Categoria</td>
									<td>
										<?php
												$sentencia = "SELECT * from categoria";
												$resultado = $conexion->prepare($sentencia);
												$resultado->execute();
												$cat = $resultado->fetchAll(PDO::FETCH_ASSOC);
										 ?>
											<div class="container">
												<select class="form-control" name="categoria">
													<?php foreach ($cat as $c): ?>
														<option value="<?php echo $c['id_categoria']; ?>"><?php echo $c['nombre_categoria']; ?></option>
													<?php endforeach; ?>
												</select>
											</div>
									</td>
								</tr>

							</table>
						</div>
						<div class="form-group">
							<label for="">Nombre</label>
							<input type="text" name="nombre" value="" class="form-control">
						</div>
						<div class="form-group">
							<label for="">Precio</label>
							<input type="number" name="precio" value="0.00" min="0.00" step="0.01" class="form-control">
						</div>
						<div class="form-group">
							<label for="">Detalle</label>
							<input type="text" name="Detalle" placeholder="detalles del producto" class="form-control">
						</div>
						<div class="form-group">
							<label for="">Cantidad</label>
							<input type="number" name="cantidad" value="1" min="1" step="1" class="form-control">
						</div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <input type="submit" name="OkProd" value="Guardar" class="btn btn-success">
      </div>
			</form>
    </div>
  </div>
</div>
				<!--Jquery, Popper, Bootstrap -->
				<script src="jquery/jquery-3.3.1.min.js"></script>
				<script src="popper/popper.min.js"></script>
				<script src="bootstrap/js/bootstrap.min.js"></script>

				<!-- Datatable -->

				<script type="text/javascript" src="datatables/datatables.min.js"></script>
				<script type="text/javascript" src="main.js"></script>


	<?php
			if (isset($_POST['Editar'])) {
				$idEdit = $_POST['id'];
				$nombre = $_POST['nombre'];
				$precio = $_POST['precio'];
				$detalle = $_POST['detalle'];
				$cantidad = $_POST['cantidad'];
				$categoria = $_POST['id_categoria'];
?>
			<div class="text-center">
				<h4>Editar Producto</h4>
			</div>
			<form class="" action="Mantenimientos/crud_producto.php" method="post">
				<div class="form-group">
					<table>
						<tr>
							<td>Categoria</td>
							<td>
								<?php
										$sentencia = "SELECT * from categoria";
										$resultado = $conexion->prepare($sentencia);
										$resultado->execute();
										$cat = $resultado->fetchAll(PDO::FETCH_ASSOC);
								 ?>
									<div class="container">
										<select class="form-control" name="categoria">
											<?php foreach ($cat as $c): ?>
												<option value="<?php echo $c['id_categoria']; ?>"><?php echo $c['nombre_categoria']; ?></option>
											<?php endforeach; ?>
										</select>
									</div>
							</td>
						</tr>

					</table>
				</div>
				<div class="form-group">
					<label for="">Nombre</label>
					<input type="text" name="nombre" value="<?php echo $nombre ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="">Precio</label>
					<input type="number" name="precio" value="<?php echo $precio ?>" min="0.00" step="0.01" class="form-control">
				</div>
				<div class="form-group">
					<label for="">Detalle</label>
					<input type="text" name="Detalle" value="<?php echo $detalle ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="">Cantidad</label>
					<input type="number" name="cantidad" value="<?php echo $cantidad ?>" min="1" step="1" class="form-control">
				</div>
				<input type="hidden" name="idEdit" value="<?php echo $idEdit ?>">
				<div class="form-group">
					<input type="submit" name="okEdit" value="Guardar cambios" class="btn btn-primary">
					<input type="submit" name="cancel" value="Cancelar" class="btn btn-danger">
				</div>
			</form>

<?php
}else if (isset($_POST['Eliminar'])) {
	$id = $_POST['id'];

	$sentencia =  "DELETE FROM Producto WHERE id_producto = $id";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	echo "
			<script>
				alert('Se eliminaron los datos correctamente');
				window.location= 'Productos.php'
			</script>";
}

	 ?>

</body>
</html>
