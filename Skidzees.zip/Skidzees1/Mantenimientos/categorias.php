<?php
include_once 'Conexion/conexion.php';
$objeto = new conexion();
$conexion = $objeto->conectar();

$consulta = "SELECT * FROM Categoria";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width-divece-width, initial-scale=1 shrink-to-fit=no">
	<link rel="shortcut icon" href="#">
<title>Documento sin título</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css">
	<link rel="stylesheet" type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
</head>
<body>
	<header>

	</header>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<button id="btnNuevo" type="button" class="btn btn-outline-success" data-toggle="modal" data-target="#modalCrud">Nuevo</button>
		</div>
		</div>
	</div>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<div class="table-responsive">
			<table id="tabla" class="table table-striped table-bordered table-condensed" style="width: 100%">
				<thead class="text-center">
					<tr>
						<th>Categoria</th>
						<th>Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($data as $dat){
					?>
						<tr>
						<td class="text-center"><?php echo $dat ['nombre_categoria']?></td>
						<form class="" action="" method="post">
							<td class="text-center">
								<input type="submit" name="Editar" value="Editar" class="btn btn-primary">
								<input type="submit" name="Eliminar" value="Eliminar" class="btn btn-danger">
						  </td>

							<input type="hidden" name="id" value="<?php echo $dat['id_categoria'] ?>">
							<input type="hidden" name="nombre" value="<?php echo $dat['nombre_categoria'] ?>">
						</form>
						</tr>
					<?php
					}
						?>
				</tbody>

				</table>
			</div>
		</div>
		</div>
	</div>
	<!--Modal Crud-->
	<div class="modal fade" id="modalCrud" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Nueva Categoria</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container">
					<form class="" action="Mantenimientos/crud_categoria.php" method="post">
						<div class="form-group">
							<label for="">Nombre de la categoria</label>
							<input type="text" name="nombre" value="" class="form-control">
						</div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <input type="submit" name="OkCat" value="Guardar" class="btn btn-success">
      </div>
			</form>
    </div>
  </div>
</div>
				<!--Jquery, Popper, Bootstrap -->
				<script src="jquery/jquery-3.3.1.min.js"></script>
				<script src="popper/popper.min.js"></script>
				<script src="bootstrap/js/bootstrap.min.js"></script>

				<!-- Datatable -->

				<script type="text/javascript" src="datatables/datatables.min.js"></script>
				<script type="text/javascript" src="main.js"></script>


	<?php
			if (isset($_POST['Editar'])) {
				$idEdit = $_POST['id'];
				$nombre = $_POST['nombre'];
?>
			<div class="container">
				<div class="text-center">
					<h4>Editar Categoria</h4>
					<form class="" action="Mantenimientos/crud_categoria.php" method="post">
						<table align="center">
							<tr>
								<td>Nombre: &nbsp; &nbsp; &nbsp;</td>
								<td><input type="text" name="nombreE" value="<?php echo $nombre ?>" class="form-control"></td>
							</tr>
						</table>
						<input type="hidden" name="idEdit" value="<?php echo $idEdit ?>">
						<div class="form-group">
							<input type="submit" name="okEdit" value="Guardar" class="btn btn-primary">
							<input type="submit" name="cancel" value="Cancelar" class="btn btn-danger">
						</div>
					</form>
				</div>
			</div>


<?php
}else if (isset($_POST['Eliminar'])) {
	$id = $_POST['id'];

	$sentencia =  "DELETE FROM Categoria WHERE id_categoria = $id";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	echo "
			<script>
				alert('Se eliminaron los datos correctamente');
				window.location= 'Categoria.php'
			</script>";
}

	 ?>

</body>
</html>
