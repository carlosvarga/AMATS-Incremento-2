<?php

include_once "../Conexion/conexion.php";
$objeto = new conexion();
$conexion = $objeto->conectar();

if (isset($_POST['OkEmp'])) {
	$nombre1 = $_POST['nombre1'];
	$nombre2 = $_POST['nombre2'];
	$apellido1 = $_POST['apellido1'];
	$apellido2 = $_POST['apellido2'];
	$direccion = $_POST['direccion'];
	$username = $_POST['user'];
	$rol = $_POST['rol'];
	$pass = $_POST['pass'];

	$sentencia =  "INSERT INTO empleado (id_rol, nombre1, nombre2, apellido1, apellido2, direccion, username, PASSWORD, Estado) VALUES ($rol, '$nombre1', '$nombre2', '$apellido1', '$apellido2', '$direccion', '$username', '$pass', 1)";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("Location: ../Empleados.php");



}
if (isset($_POST['okEditEmp'])) {
	$nombre1 = $_POST['nombre1E'];
	$nombre2 = $_POST['nombre2E'];
	$apellido1 = $_POST['apellido1E'];
	$apellido2 = $_POST['apellido2E'];
	$direccion = $_POST['direccionE'];
	$username = $_POST['userE'];
	$rol = $_POST['rolE'];
	$pass = $_POST['passE'];
	$id = $_POST['idEdit'];

	$sentencia =  "UPDATE empleado SET nombre1 = '$nombre1', nombre2 = '$nombre2', apellido1 = '$apellido1', apellido2 = '$apellido2', direccion = '$direccion', username = '$username', PASSWORD = $pass	 WHERE id_empleado = $id";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("location: ../Empleados.php");
}

if (isset($_POST['cancel'])) {
	header("location: ../Empleados.php");
}
