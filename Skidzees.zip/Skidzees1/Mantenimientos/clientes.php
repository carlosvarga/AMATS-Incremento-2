<?php
include_once 'Conexion/conexion.php';
$objeto = new conexion();
$conexion = $objeto->conectar();

$consulta = "SELECT * FROM Cliente";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width-divece-width, initial-scale=1 shrink-to-fit=no">
	<link rel="shortcut icon" href="#">
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css">
	<link rel="stylesheet" type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
</head>
<body>
	<header>

	</header>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<button id="btnNuevo" type="button" class="btn btn-outline-success" data-toggle="modal" data-target="#modalCrud">Nuevo</button>
		</div>
		</div>
	</div>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<div class="table-responsive">
			<table id="tabla" class="table table-striped table-bordered table-condensed" style="width: 100%">
				<thead class="text-center">
					<tr>
						<th colspan="2">Nombres</th>
						<th colspan="2">Apellidos</th>
            <th>Direccion</th>
            <th colspan="2">Telefonos</th>
            <th>Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($data as $dat){
					?>
						<tr>
						<td class="text-center"><?php echo $dat ['nombre1']?></td>
            <td class="text-center"><?php echo $dat ['nombre2']?></td>
            <td class="text-center"><?php echo $dat ['apellido1']?></td>
            <td class="text-center"><?php echo $dat ['apellido2']?></td>
            <td class="text-center"><?php echo $dat ['direccion']?></td>
            <td class="text-center"><?php echo $dat ['telefonocelu']?></td>
            <td class="text-center"><?php echo $dat ['telefonocasa']?></td>
						<form class="" action="" method="post">
							<td class="text-center">
								<input type="submit" name="Editar" value="Editar" class="btn btn-primary">
								<input type="submit" name="Eliminar" value="Eliminar" class="btn btn-danger">
						  </td>

							<input type="hidden" name="id" value="<?php echo $dat['id_cliente'] ?>">
							<input type="hidden" name="nombre1" value="<?php echo $dat['nombre1'] ?>">
              <input type="hidden" name="nombre2" value="<?php echo $dat['nombre2'] ?>">
							<input type="hidden" name="apellido1" value="<?php echo $dat['apellido1'] ?>">
              <input type="hidden" name="apellido2" value="<?php echo $dat['apellido2'] ?>">
							<input type="hidden" name="direccion" value="<?php echo $dat['direccion'] ?>">
              <input type="hidden" name="telefonocelu" value="<?php echo $dat['telefonocelu'] ?>">
              <input type="hidden" name="telefonocasa" value="<?php echo $dat['telefonocasa'] ?>">
						</form>
						</tr>
					<?php
					}
						?>
				</tbody>

				</table>
			</div>
		</div>
		</div>
	</div>
	<!--Modal Crud-->
	<div class="modal fade" id="modalCrud" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Nueva Categoria</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container">
					<form class="" action="Mantenimientos/crud_cliente.php" method="post">
            <div class="form-group">
              <label for="">Nombre 1</label>
              <input type="text" name="nombre1" value="" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Nombre 2</label>
              <input type="text" name="nombre2" value="" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Apellido 1</label>
              <input type="text" name="apellido1" value="" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Apellido 2</label>
              <input type="text" name="apellido2" value="" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Direccion</label>
              <input type="text" name="direccion" value="" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Telefono celular</label>
              <input type="number" name="tel1" value="" class="form-control" min="10000000" max="99999999" step="1">
            </div>
            <div class="form-group">
              <label for="">Telefono de casa</label>
              <input type="number" name="tel2" value="" class="form-control" min="10000000" max="99999999" step="1">
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <input type="submit" name="OkClie" value="Guardar" class="btn btn-success">
      </div>
			</form>
    </div>
  </div>
</div>
				<!--Jquery, Popper, Bootstrap -->
				<script src="jquery/jquery-3.3.1.min.js"></script>
				<script src="popper/popper.min.js"></script>
				<script src="bootstrap/js/bootstrap.min.js"></script>

				<!-- Datatable -->

				<script type="text/javascript" src="datatables/datatables.min.js"></script>
				<script type="text/javascript" src="main.js"></script>


	<?php
			if (isset($_POST['Editar'])) {
        $idEdit = $_POST['id'];
				$nombre1 = $_POST['nombre1'];
        $nombre2 = $_POST['nombre2'];
        $apellido1 = $_POST['apellido1'];
        $apellido2 = $_POST['apellido2'];
        $direccion = $_POST['direccion'];
        $tel1 = $_POST['telefonocelu'];
        $tel2 = $_POST['telefonocasa'];
?>
			<div class="container">
				<div class="text-center">
					<h4>Editar Categoria</h4>
					<form class="" action="Mantenimientos/crud_cliente.php" method="post">
            <div class="form-group">
              <label for="">Nombre 1</label>
              <input type="text" name="nombre1E" value="<?php echo $nombre1 ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Nombre 2</label>
              <input type="text" name="nombre2E" value="<?php echo $nombre2 ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Apellido 1</label>
              <input type="text" name="apellido1E" value="<?php echo $apellido1 ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Apellido 1</label>
              <input type="text" name="apellido2E" value="<?php echo $apellido2 ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Direccion</label>
              <input type="text" name="direccionE" value="<?php echo $direccion ?>" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="">Telefono celular</label>
              <input type="number" name="tel1E" value="<?php echo $tel1 ?>" class="form-control" min="10000000" max="99999999" step="1">
            </div>
            <div class="form-group">
              <label for="">Telefono de casa</label>
              <input type="number" name="tel2E" value="<?php echo $tel2 ?>" class="form-control" min="10000000" max="99999999" step="1">
            </div>
						<input type="hidden" name="idEdit" value="<?php echo $idEdit ?>" class="form-control">
						<div class="form-group">
							<input type="submit" name="okEditClie" value="Guardar" class="btn btn-primary">
							<input type="submit" name="cancel" value="Cancelar" class="btn btn-danger">
						</div>
					</form>
				</div>
			</div>


<?php
}else if (isset($_POST['Eliminar'])) {
	$id = $_POST['id'];

	$sentencia =  "DELETE FROM Cliente WHERE id_cliente = $id";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	echo "
			<script>
				alert('Se eliminaron los datos correctamente');
				window.location= 'Clientes.php'
			</script>";
}

	 ?>

</body>
</html>
