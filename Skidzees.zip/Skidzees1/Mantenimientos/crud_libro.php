<?php

include_once "../Conexion/conexion.php";
$objeto = new conexion();
$conexion = $objeto->conectar();

if (isset($_POST['OkLibro'])) {
	$titulo = $_POST['titulo'];
	$autor =$_POST['autor'];
	$disponibilidad = $_POST['disponibilidad'];
	$cantidad = $_POST['cantidad'];
	$estado = $_POST['estado'];

	$sentencia =  "INSERT INTO Libros (titulo_libro, autor_libro, disponibilidad, cantidad, estado) values ('$titulo', '$autor', $disponibilidad, $cantidad, '$estado')";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("location: ../Libros.php");


}
if (isset($_POST['okEdit'])) {
	$idEdit = $_POST['idEditE'];
	$titulo = $_POST['tituloE'];
	$autor =$_POST['autorE'];
	$disponibilidad = $_POST['disponibilidadE'];
	$cantidad = $_POST['cantidadE'];
	$estado = $_POST['estadoE'];

	$sentencia =  "UPDATE Libros SET titulo_libro = '$titulo', autor_libro = '$autor', disponibilidad = $disponibilidad, cantidad = $cantidad, estado = '$estado' WHERE id_libro = $idEdit";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("location: ../Libros.php");
}

if (isset($_POST['cancel'])) {
	header("location: ../Libros.php");
}
