<?php

include_once "../Conexion/conexion.php";
$objeto = new conexion();
$conexion = $objeto->conectar();

if (isset($_POST['OkClie'])) {
	$nombre1 = $_POST['nombre1'];
	$nombre2 = $_POST['nombre2'];
	$apellido1 = $_POST['apellido1'];
	$apellido2 = $_POST['apellido2'];
	$direccion = $_POST['direccion'];
	$tel1 = $_POST['tel1'];
	$tel2 = $_POST['tel2'];

	$sentencia =  "INSERT INTO cliente (id_alquileres, nombre1, nombre2, apellido1, apellido2, direccion, telefonocelu, telefonocasa) VALUES (NULL, '$nombre1', '$nombre2', '$apellido1', '$apellido2', '$direccion', $tel1, $tel2)";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("Location: ../Clientes.php");



}
if (isset($_POST['okEditClie'])) {
	$id = $_POST['idEdit'];
	$nombre1 = $_POST['nombre1E'];
	$nombre2 = $_POST['nombre2E'];
	$apellido1 = $_POST['apellido1E'];
	$apellido2 = $_POST['apellido2E'];
	$direccion = $_POST['direccionE'];
	$tel1 = $_POST['tel1E'];
	$tel2 = $_POST['tel2E'];

	$sentencia =  "UPDATE Cliente SET id_alquileres = NULL, nombre1 = '$nombre1', nombre2 = '$nombre2', apellido1 = '$apellido1', apellido2 = '$apellido2', direccion = '$direccion', telefonocelu = $tel1, telefonocasa = $tel2 WHERE id_cliente = $id";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("location: ../Clientes.php");
}

if (isset($_POST['cancel'])) {
	header("location: ../Clientes.php");
}
