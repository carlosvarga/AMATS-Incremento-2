<?php
include_once 'Conexion/conexion.php';
$objeto = new conexion();
$conexion = $objeto->conectar();

$consulta = "SELECT * FROM Rol";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width-divece-width, initial-scale=1 shrink-to-fit=no">
	<link rel="shortcut icon" href="#">
<title>Documento sin título</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css">
	<link rel="stylesheet" type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
</head>
<body>
	<header>

	</header>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<button id="btnNuevo" type="button" class="btn btn-outline-success" data-toggle="modal" data-target="#modalCrud">Nuevo</button>
		</div>
		</div>
	</div>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<div class="table-responsive">
			<table id="tabla" class="table table-striped table-bordered table-condensed" style="width: 100%">
				<thead class="text-center">
					<tr>
						<th>Rol</th>
						<th>Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($data as $dat){
					?>
					<tr>
							<td align="center"><?php echo $dat ['nombre']?></td>

							<form class="" action="" method="post">
									<td align="center"><input type="submit" name="Editar" value="Editar" class="btn btn-primary">
									<input type="submit" name="Eliminar" value="Eliminar" class="btn btn-danger"></td>
									<input type="hidden" name="id" value="<?php echo $dat['id_rol'] ?>">
									<input type="hidden" name="nombre" value="<?php echo $dat['nombre'] ?>">
							</form>
					</tr>
					<?php
					}
						?>
				</tbody>

				</table>
			</div>
		</div>
		</div>
	</div>
	<!--Modal Crud-->
	<div class="modal fade" id="modalCrud" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Nuevo Rol</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container">
					<form class="" action="Mantenimientos/crud_rol.php" method="post">
						<div class="form-group">
							<label for="">Rol</label>
							<input type="text" name="rol" value="" class="form-control">
						</div>

        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <input type="submit" name="OkLibro" value="Guardar" class="btn btn-success">
      </div>
			</form>
    </div>
  </div>
</div>
				<!--Jquery, Popper, Bootstrap -->
				<script src="jquery/jquery-3.3.1.min.js"></script>
				<script src="popper/popper.min.js"></script>
				<script src="bootstrap/js/bootstrap.min.js"></script>

				<!-- Datatable -->

				<script type="text/javascript" src="datatables/datatables.min.js"></script>
				<script type="text/javascript" src="main.js"></script>


	<?php
			if (isset($_POST['Editar'])) {
				$idEdit = $_POST['id'];
				$nombre = $_POST['nombre'];

?>

			<form class="" action="Mantenimientos/crud_rol.php" method="post">
				<div class="form-group">
					<label for="">Rol</label>
					<input type="text" name="nombreE" value="<?php echo $nombre ?>" class="form-control">
				</div>

				<input type="hidden" name="idEditE" value="<?php echo $idEdit ?>">
				<div class="form-group">
					<input type="submit" name="okEdit" value="Guardar cambios" class="btn btn-primary" align="center">
					<input type="button" name="cancel" value="Cancelar" class="btn btn-danger" align="center">
				</div>
			</form>

<?php
}else if (isset($_POST['Eliminar'])) {
	$id = $_POST['id'];

	$sentencia =  "DELETE FROM Rol WHERE id_rol = $id";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	echo "
			<script>
				alert('Se eliminaron los datos correctamente');
				window.location= 'Roles.php'
			</script>";
}

	 ?>

</body>
</html>
