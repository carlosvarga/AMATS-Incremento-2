<?php

include_once "../Conexion/conexion.php";
$objeto = new conexion();
$conexion = $objeto->conectar();

if (isset($_POST['OkLibro'])) {
	$nombre = $_POST['rol'];
	$sentencia =  "INSERT INTO Rol (nombre) values ('$nombre')";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("location: ../Roles.php");


}
if (isset($_POST['okEdit'])) {
	$idEdit = $_POST['idEditE'];
	$nombre = $_POST['nombreE'];


	$sentencia =  "UPDATE Rol SET nombre = '$nombre' WHERE id_rol = $idEdit";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("location: ../Roles.php");
}
