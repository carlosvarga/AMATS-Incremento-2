<?php

include_once "../Conexion/conexion.php";
$objeto = new conexion();
$conexion = $objeto->conectar();

if (isset($_POST['OkProd'])) {

	$categoria = $_POST['categoria'];
	$nombre = $_POST['nombre'];
	$precio = $_POST['precio'];
	$detalle = $_POST['Detalle'];
	$cantidad = $_POST['cantidad'];

	$sentencia =  "INSERT INTO producto (id_categoria, nombre_producto, precio, detalle, cantidad) VALUES ($categoria, '$nombre', '$precio', '$detalle', $cantidad)";
	$resultado = $conexion->prepare($sentencia);

	if ($resultado->execute()) {
		echo "ok";
		header("location: ../Productos.php");

	}else {
		echo "nel";
	}



}
if (isset($_POST['okEdit'])) {
	$categoria = $_POST['categoria'];
	$nombre = $_POST['nombre'];
	$precio = $_POST['precio'];
	$detalle = $_POST['Detalle'];
	$cantidad = $_POST['cantidad'];

	$id = $_POST['idEdit'];

	$sentencia =  "UPDATE producto SET id_categoria = $categoria, nombre_producto = '$nombre', precio = '$precio', detalle = '$detalle', cantidad = $cantidad WHERE id_producto = $id";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("location: ../Productos.php");
}

if (isset($_POST['cancel'])) {
	header("location: ../Libros.php");
}
