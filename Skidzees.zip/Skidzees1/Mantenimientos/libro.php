<?php
include_once 'Conexion/conexion.php';
$objeto = new conexion();
$conexion = $objeto->conectar();

$consulta = "SELECT * FROM Libros";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width-divece-width, initial-scale=1 shrink-to-fit=no">
	<link rel="shortcut icon" href="#">
<title>Documento sin título</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css">
	<link rel="stylesheet" type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
</head>
<body>
	<header>

	</header>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<button id="btnNuevo" type="button" class="btn btn-outline-success" data-toggle="modal" data-target="#modalCrud">Nuevo</button>
		</div>
		</div>
	</div>

	<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<div class="table-responsive">
			<table id="tabla" class="table table-striped table-bordered table-condensed" style="width: 100%">
				<thead class="text-center">
				<tr>
					<th>Titulo Libro</th>
					<th>Autor Libro</th>
					<th>Disponibilidad</th>
					<th>Cantidad</th>
					<th>Estado</th>
					<th>Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($data as $dat){
					?>
					<tr>
					<td><?php echo $dat ['titulo_libro']?></td>
					<td><?php echo $dat ['autor_libro']?></td>
					<td><?php echo $dat ['disponibilidad']?></td>
					<td><?php echo $dat ['cantidad']?></td>
					<td><?php echo $dat ['estado']?></td>
					<form class="" action="" method="post">
						<td>
							<input type="submit" name="Editar" value="Editar" class="btn btn-primary">
							<input type="submit" name="Eliminar" value="Eliminar" class="btn btn-danger">
					  </td>

						<input type="hidden" name="id" value="<?php echo $dat['id_libro'] ?>">
						<input type="hidden" name="titulo" value="<?php echo $dat['titulo_libro'] ?>">
						<input type="hidden" name="autor" value="<?php echo $dat['autor_libro'] ?>">
						<input type="hidden" name="disponibilidad" value="<?php echo $dat['disponibilidad'];?>">
						<input type="hidden" name="cantidad" value="<?php echo $dat['cantidad'] ?>">
						<input type="hidden" name="estado" value="<?php echo $dat['estado'] ?>">
					</form>
					</tr>
					<?php
					}
						?>
				</tbody>

				</table>
			</div>
		</div>
		</div>
	</div>
	<!--Modal Crud-->
	<div class="modal fade" id="modalCrud" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Nuevo Libro</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container">
					<form class="" action="Mantenimientos/crud_libro.php" method="post">
						<div class="form-group">
							<label for="">Titulo</label>
							<input type="text" name="titulo" value="" class="form-control">
						</div>
						<div class="form-group">
							<label for="">Autor</label>
							<input type="text" name="autor" value="" class="form-control">
						</div>
						<div class="form-group">
							<label for="">Disponibilidad</label>
							<select class="custom-select" name="disponibilidad">
								<option value="1">Disponible</option>
								<option value="2">No disponible</option>
							</select>
						</div>
						<div class="form-group">
							<label for="">cantidad</label>
							<input type="number" name="cantidad" value="1" min="1" step="1" class="form-control">
						</div>
						<div class="form-group">
							<label for="">Estado</label>
							<input type="text" name="estado" placeholder="Indique el estado fisico del libro" class="form-control">
						</div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <input type="submit" name="OkLibro" value="Guardar" class="btn btn-success">
      </div>
			</form>
    </div>
  </div>
</div>
				<!--Jquery, Popper, Bootstrap -->
				<script src="jquery/jquery-3.3.1.min.js"></script>
				<script src="popper/popper.min.js"></script>
				<script src="bootstrap/js/bootstrap.min.js"></script>

				<!-- Datatable -->

				<script type="text/javascript" src="datatables/datatables.min.js"></script>
				<script type="text/javascript" src="main.js"></script>


	<?php
			if (isset($_POST['Editar'])) {
				$idEdit = $_POST['id'];
				$titulo = $_POST['titulo'];
				$autor =$_POST['autor'];
				$disponibilidad = $_POST['disponibilidad'];
				$cantidad = $_POST['cantidad'];
				$estado = $_POST['estado'];
?>

			<form class="" action="Mantenimientos/crud_libro.php" method="post">
				<div class="form-group">
					<label for="">Titulo</label>
					<input type="text" name="tituloE" value="<?php echo $titulo ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="">Autor</label>
					<input type="text" name="autorE" value="<?php echo $autor ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="">Disponibilidad</label>
					<select class="custom-select" name="disponibilidadE">
						<option value="1">Disponible</option>
						<option value="2">No disponible</option>
					</select>
				</div>
				<div class="form-group">
					<label for="">cantidad</label>
					<input type="number" name="cantidadE" value="1" min="1" step="1" class="form-control" value="<?php echo $cantidad ?>">
				</div>
				<div class="form-group">
					<label for="">Estado</label>
					<input type="text" name="estadoE" class="form-control" value="<?php echo $estado ?>">
				</div>
				<input type="hidden" name="idEditE" value="<?php echo $idEdit ?>">
				<div class="form-group">
					<input type="submit" name="okEdit" value="Guardar cambios" class="btn btn-primary">
					<input type="submit" name="cancel" value="Cancelar" class="btn btn-danger">
				</div>
			</form>

<?php
}else if (isset($_POST['Eliminar'])) {
	$id = $_POST['id'];

	$sentencia =  "DELETE FROM Libros WHERE id_libro = $id";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	echo "
			<script>
				alert('Se eliminaron los datos correctamente');
				window.location= 'libros.php'
			</script>";
}

	 ?>

</body>
</html>
