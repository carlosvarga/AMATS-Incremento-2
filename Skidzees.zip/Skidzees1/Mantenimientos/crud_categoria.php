<?php

include_once "../Conexion/conexion.php";
$objeto = new conexion();
$conexion = $objeto->conectar();

if (isset($_POST['OkCat'])) {
	$nombre = $_POST['nombre'];

	$sentencia =  "INSERT INTO Categoria (nombre_categoria) values ('$nombre')";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("location: ../Categoria.php");


}
if (isset($_POST['okEdit'])) {
	$idEdit = $_POST['idEdit'];
	$nombre = $_POST['nombreE'];

	$sentencia =  "UPDATE Categoria SET nombre_categoria = '$nombre' WHERE id_categoria = $idEdit";
	$resultado = $conexion->prepare($sentencia);
	$resultado->execute();

	header("location: ../Categoria.php");
}

if (isset($_POST['cancel'])) {
	header("location: ../Categoria.php");
}
