<?php
  session_start();
  include_once("Conexion/conexion.php");
  $objeto = new conexion();
  $conexion = $objeto->conectar();
if (isset($_SESSION["id_empleado"])) {
  $id = $_SESSION["id_empleado"];
  $id_rol = $_SESSION['tipo'];
  if (isset($_POST["accDatos"])) {
    $nombre1 = $_POST["nombre1"];
    $nombre2 = $_POST["nombre2"];
    $apellido1 = $_POST["apellido1"];
    $apellido2 = $_POST["apellido2"];
    $usuario = $_POST["user"];
    $contra = $_POST["pass"];
    $direccion = $_POST["direccion"];

    $sentencia = "UPDATE empleado SET id_rol= $id_rol ,nombre1='$nombre1',nombre2='$nombre2',apellido1='$apellido1',apellido2='$apellido2',direccion='$direccion', username='$usuario',PASSWORD='$contra',Estado=1 WHERE id_empleado= $id";
    $sql = $conexion->prepare($sentencia);
    if ($sql->execute()) {
      echo "
      <script>
          alert('Datos actualizados correctamente');
          window.location= 'login/logout.php';
      </script>
      ";
    }else {
      echo "
      <script>
          alert('Error');
          window.location= 'index.php';
      </script>
      ";
    }

  }
}
 ?>
