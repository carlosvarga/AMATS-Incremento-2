<?php
session_start();
  if (!isset($_SESSION['usuario'])) {
    header('location: login/login.php');
  }else{
    if ($_SESSION['tipo'] == 1) {
      include_once("Vistas/Parte_Superior_Admin.php");
    }else if ($_SESSION['tipo'] == 2) {
      include_once("Vistas/Parte_Superior_Vendedor.php");
    }
     require_once('Conexion/conexion.php');
?>
<div class="container">
	<?php include_once("indexal.php"); ?>
</div>
<div class="container">
	<?php include_once("indexal1.php"); ?>
</div>
<div class="container">
	<?php include_once("indexal2.php"); ?>
</div>

<?php include_once("Vistas/Parte_Inferior.php"); }?>

