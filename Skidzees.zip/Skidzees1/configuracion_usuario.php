<?php
session_start();
include_once("Conexion/conexion.php");
$objeto = new conexion();
$conexion = $objeto->conectar();
$id_Empleado = $_SESSION['id_empleado'];
$sql = "CALL SeleccionarEmpleadoPorId('$id_Empleado')";
$resultado = $conexion->prepare($sql);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);


  if (!isset($_SESSION['usuario'])) {
    header('location: login/login.php');
  }else{
    if ($_SESSION['tipo'] == 1) {
      include_once("Vistas/Parte_Superior_Admin.php");
    }else if ($_SESSION['tipo'] == 2) {
      include_once("Vistas/Parte_Superior_Vendedor.php");
    }
?>
  <div class="container">
    <form class="" action="UpdatePerfil.php" method="post">
      <div class="container">
        <table class="table-hover" align="center">
              <tr>
                <td colspan="5" align="center"><img src="img/logo.png" height="250" width="250" alt=""> </td>
              </tr>
              <?php foreach ($data as $d): ?>
                <tr>
                  <td><label for="">Usuario: &nbsp;</label> </td>
                  <td> <input type="text" name="user" value="<?php echo $d['username']; ?>" class="form-control"> </td>
                  <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
                  <td>Contraseña: &nbsp;</td>
                  <td> <input type="password" name="pass" value="<?php echo $d['PASSWORD']; ?>" class="form-control"> </td>
                </tr>
                <tr>
                  <td><label for="">Primer nombre: &nbsp;</label> </td>
                  <td> <input type="text" name="nombre1" value="<?php echo $d['nombre1']; ?>" class="form-control"> </td>
                  <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
                  <td><label for="">Segundo nombre: &nbsp;</label> </td>
                  <td> <input type="text" name="nombre2" value="<?php echo $d['nombre2']; ?>" class="form-control"> </td>
                </tr>
                <tr>
                  <td><label for="">Primer apellido: &nbsp;</label> </td>
                  <td> <input type="text" name="apellido1" value="<?php echo $d['apellido1']; ?>" class="form-control"> </td>
                  <td>&nbsp;</td>
                  <td><label for="">Segundo apellido: &nbsp;</label> </td>
                  <td> <input type="text" name="apellido2" value="<?php echo $d['apellido2']; ?>" class="form-control"> </td>
                </tr>
                <tr>
                  <td><label for="">Direccion: &nbsp;</label> </td>
                  <td colspan="4"> <input type="text" name="direccion" value="<?php echo $d['direccion']; ?>" class="form-control"> </td>
                </tr>
                <tr>
                  <td align="center" colspan="2"> <a href="indx.php" class="btn btn-danger">Cancelar</a> </td>
                  <td align="center" colspan="3"> <input type="submit" name="accDatos" value="Confirmar cambios" class="btn btn-success"> </td>
                </tr>
              <?php endforeach; ?>
        </table>
    </div>
  </form>

  </div>
<?php include_once("Vistas/Parte_Inferior.php"); }?>
