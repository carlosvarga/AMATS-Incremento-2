<?php
session_start();
  if (!isset($_SESSION['usuario'])) {
    header('location: login/login.php');
  }else{
    if ($_SESSION['tipo'] == 1) {
      include_once("Vistas/Parte_Superior_Admin.php");
    }else if ($_SESSION['tipo'] == 2) {
      header("Location: Index.php");
    }
?>
<div class="container">
  <?php include_once("Mantenimientos/producto.php"); ?>
</div>

<?php
     include_once("Vistas/Parte_Inferior.php");
    }
?>
