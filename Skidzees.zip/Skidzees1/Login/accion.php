<?php
  session_start();
  require_once('../Conexion/conexion.php');
  $objeto = new conexion();
  $conexion = $objeto->conectar();
if (isset($_POST['user'])) {
  $user = $_POST['user'];
  $pass = $_POST['pass'];
  $sql = $conexion->prepare("select * from  empleado WHERE username = '$user' and PASSWORD = '$pass'");
  $sql->execute();

  if ($sql->rowCount() > 0) {
    $datos = $sql->fetchAll(PDO::FETCH_OBJ);

    foreach ($datos as $dato) {
      $_SESSION['usuario'] = $dato->username;
      $nombre = $dato->nombre1;
      $apellido = $dato->apellido1;
      $id = $dato->id_rol;
      $id_Empleado = $dato->id_empleado;

      $_SESSION['id_empleado'] = $id_Empleado;
      $_SESSION['tipo'] = $id;
    }
    if ($id == 1 || $id ==2) {
      header('Location: ../Index.php');
    }

  }else {
   echo("<script>alert('Conexion erronea')</script>");
   header('location: login.php');
  }
}
?>
