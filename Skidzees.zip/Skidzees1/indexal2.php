<?php

$consulta = "SELECT VE.id_venta, PR.nombre, PR.cantidad, PR.precio FROM Venta AS VE
INNER JOIN Producto AS PR ON VE.id_producto = PR.id_producto";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
?>

<html lang="es">
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width-divece-width, initial-scale=1 shrink-to-fit=no">
	<link rel="shortcut icon" href="#">
	<title>mostrar datos</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="main.css">
	
	
	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css">
	<link rel="stylesheet" type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
	
</head>
	<body>
		<header>
			<div class="alert alert-info">
			
			</div>
		</header>

		<section>
  <div class="card-body">
    <h5 class="card-title">Ventas de Hoy</h5>
    <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
  <div class="card-header">Header</div>
  <div class="card-body">
    <h5 class="card-title">Danger card title</h5>
       <table border="1" >
        <tr>
      <td>Venta</td>
      <td>Nombre Producto</td>
      <td>Cantidad</td>
      <td>Total</td>
            
    </tr>

		  <?php 
    
    foreach($data as $dat)
          { 
          ?>
  
    <tr>
      <td><?php echo $dat['id_venta'] ?></td>
      <td><?php echo $dat['nombre'] ?></td>
      <td><?php echo $dat['cantidad'] ?></td>
      <td><?php echo $dat['precio'] ?></td>
      
    </tr>

<?php 
  }
   ?>
   </table>
    
  </div>
</div>
 

		</section>
</body>
</html>

