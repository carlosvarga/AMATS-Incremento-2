<?php


$consulta = "SELECT AL.id_alquileres, LI.titulo_libro FROM Alquileres AS AL
INNER JOIN Libros AS LI ON AL.id_libro = LI.id_libro";
$resultado = $conexion->prepare($consulta);
$resultado->execute();
$data=$resultado->fetchAll(PDO::FETCH_ASSOC);
?>

<html lang="es">
	<head>
	<meta name="viewport" content="width-divece-width, initial-scale=1 shrink-to-fit=no">
	<link rel="shortcut icon" href="#">
<title>Documento sin título</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="main.css">
	
	
	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css">
	<link rel="stylesheet" type="text/css" href="datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
</head>
	
</head>
	<body>
		<header>
			<div class="alert alert-info">
			
			</div>
		</header>

		<section>

  <div class="card-body">
    <h5 class="card-title">Libros Registrados</h5>
    <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
  <div class="card-header">Header</div>
  <div class="card-body">
    <h5 class="card-title">Dark card title</h5>
    <table border="1" >
        <tr>
      <td>Numero Alquiler</td>
      <td>Libro</td>
      
    
            
    </tr>

		  <?php 
    
    foreach($data as $dat)
          { 
          ?>
  
    <tr>
      <td><?php echo $dat['id_alquileres'] ?></td>
      <td><?php echo $dat['titulo_libro'] ?></td>
      
     
      
    </tr>
    
  </div>
</div>
    

<?php 
  }
   ?>
   </table>

		</section>
</body>
</html>